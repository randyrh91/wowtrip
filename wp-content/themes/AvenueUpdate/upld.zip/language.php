<?php
/**
 * Created by Ciber-Soft.
 * User: pr0x
 * Date: 30/07/16
 * Time: 14:50
 */
define('L_ENCUENTRELO','[:en]Spot Here![:es]¡Encuentrelo Aqui!');
define('CS_L_NOMBRE','[:en]Name[:es]Nombre');